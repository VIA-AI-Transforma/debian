# SPDX-FileCopyrightText: 2023 VIA Technologies, Inc.
#
# SPDX-License-Identifier: Apache-2.0

"""
Transforma GPIO library which implements RPi.GPIO functions
"""

from Transforma.GPIO.gpio_list import _GpioList
import os
import warnings
import time

# Pin Numbering Mode
BOARD = 10
BCM = 11
TRANSFORMA = 0x40d


# Constants
UNKNOWN = -1
OUT = 0
IN  = 1


# Pull up/down options
_PUD_OFFSET = 20
PUD_OFF = 0 + _PUD_OFFSET
PUD_DOWN = 1 + _PUD_OFFSET
PUD_UP = 2 + _PUD_OFFSET 

HIGH = 1
LOW = 0


# Edge possibilities
_EDGE_OFFSET = 30
RISING = 1 + _EDGE_OFFSET
FALLING = 2 + _EDGE_OFFSET
BOTH = 3 + _EDGE_OFFSET


SERIAL = 40
SPI = 41
I2C = 42
HARD_PWM = 43


# Board info

TRANSFORMA_INFO = {
    'P1_REVISION': 1,
    'RAM': '4G, 8G',
    'REVISION': 'Unknown',
    'TYPE': 'TRANSFORMA',
    'MANUFACTURER': 'VIA',
    'PROCESSOR': 'MT8390'
    }

RPI_INFO = TRANSFORMA_INFO


# Global variables

_gpio_list = _GpioList()


# Functions

def setmode(mode):
    """Set up numbering mode to use for channels

    The mode defines the ways of numbering the IO pins.

    Args:
        BOARD (int): Use Raspberry Pi board numbers
        BCM (int): Use Broadcom GPIO 00..nn numbers
        TRANSFORMA (int): Use Transforma GPIO 00..nn numbers
    """
    tostr = { BOARD: 'BOARD', BCM: 'BCM', TRANSFORMA: 'TRANSFORMA' }
    _gpio_list.setmode(tostr[mode])


def getmode():
    """Get numbering mode used for channel numbers.

    Returns:
        BOARD, BCM, TRANSFORMA or None
    """
    toval = { 'BOARD': BOARD, 'BCM': BCM, 'TRANSFORMA': TRANSFORMA }
    mode = _gpio_list.getmode()
    return toval[mode] if mode is not None else None


def _listify(x):
    lst = list()

    if type(x) == tuple or type(x) == list:
        lst += x

    elif type(x) == int or type(x) == bool or x is None:
        lst += [x]

    else:
        raise ValueError("_listify error!", type(x))

    return lst


def setup(channel, direction, pull_up_down=PUD_OFF, initial=None):
    """Set up a GPIO channel or list of channels with a direction and (optional) pull/up down control

    Args:
        channel (int): either board pin number or BCM number depending on which mode is set.
        direction (int): IN or OUT
        pull_up_down (int): PUD_OFF (default), PUD_UP or PUD_DOWN
        initial (int or bool): Initial value for an output channel"
    """
    if pull_up_down == PUD_OFF:
        bias = "disable"
    elif pull_up_down == PUD_DOWN:
        bias = "pull_down"
    elif pull_up_down == PUD_UP:
        bias = "pull_up"
    else:
        bias = "default"

    for ch in _listify(channel):
        dir_ = "out" if direction == OUT else "in"
        # print("setup:", dir_, bias, initial)
        _gpio_list.get(ch).setup(dir_, bias, initial)


def cleanup(channel=None):
    """Clean up by resetting all GPIO channels that have been used by this program to INPUT with no pullup/pulldown and no event detection
    
    Args:
        channel (int): individual channel or list/tuple of channels to clean up.  Default - clean every channel that has been used.
    """
    for ch in _listify(channel):
        _gpio_list.cleanup(ch)


def input(channel):
    """Input from a GPIO channel

    Args:
        channel (int): either board pin number or BCM number depending on which mode is set.
    
    Returns:
        int or bool: HIGH=1=True or LOW=0=False
    """
    return HIGH if _gpio_list.get(channel).read() == True else LOW


def output(channel, value):
    """Output to a GPIO channel or list of channels

    Args:
        channel (int): either board pin number or BCM number depending on which mode is set.
        value (int or bool): 0/1 or False/True or LOW/HIGH
    """
    clist = _listify(channel)
    vlist = _listify(value)

    for i, ch in enumerate(clist):
        x = vlist[i if i < len(vlist) else 0]
        _gpio_list.get(ch).write(True if x > 0 else False)


def wait_for_edge(channel, edge, bouncetime=None, timeout=None):
    """Wait for an edge.

    Returns the channel number or None on timeout.

    Args:
        channel (int): either board pin number or BCM number depending on which mode is set.
        edge (int): RISING, FALLING or BOTH
        [bouncetime] (int): time allowed between calls to allow for switch bounce
        [timeout] (int): timeout in ms
    """
    gpio = _gpio_list.get(channel)

    if gpio.direction != "in":
        raise RuntimeError("You must setup() the GPIO channel as an input "
                           "first")

    tostr = {RISING: "rising", FALLING: "falling", BOTH: "both"}

    if edge not in tostr.keys():
        raise ValueError("The edge must be set to RISING, FALLING_EDGE "
                         "or BOTH")

    if gpio.wait_for_edge(tostr[edge], bouncetime, timeout) != False:
        return channel

    return None


def add_event_detect(channel, edge, callback=None, bouncetime=None):
    """Enable edge detection events for a particular GPIO channel.

    Args:
        channel (int): either board pin number or BCM number depending on which mode is set.
        edge (int): RISING, FALLING or BOTH
        [callback] (function): A callback function for the event (optional)
        [bouncetime] (int): Switch bounce timeout in ms for callback
    """
    gpio = _gpio_list.get(channel)

    if gpio.direction != "in":
        raise RuntimeError("You must setup() the GPIO channel as an input "
                           "first")

    tostr = {RISING: "rising", FALLING: "falling", BOTH: "both"}

    if edge not in tostr.keys():
        raise ValueError("The edge must be set to RISING, FALLING_EDGE "
                         "or BOTH")

    if (not callable(callback)) and callback is not None:
        raise TypeError("Callback Parameter must be callable")

    gpio.add_event_detect(tostr[edge], bouncetime)

    if callback is not None:
        gpio.add_event_callback(lambda: callback(channel))


def remove_event_detect(channel, timeout=0.5):
    """Remove edge detection for a particular GPIO channel

    Args:
        channel (int): either board pin number or BCM number depending on which mode is set.
    """
    gpio = _gpio_list.get(channel)
    gpio.remove_event_detect(timeout)


def add_event_callback(channel, callback):
    """Add a callback for an event already defined using add_event_detect()

    Args:
        channel (int): either board pin number or BCM number depending on which mode is set.
        callback: a callback function
    """
    if not callable(callback):
        raise TypeError("Parameter must be callable")

    gpio = _gpio_list.get(channel)

    if gpio.direction != "in":
        raise RuntimeError("You must setup() the GPIO channel as an input "
                           "first")

    if gpio.detector is None:
        raise RuntimeError("Add event detection using add_event_detect first "
                           "before adding a callback")

    gpio.add_event_callback(lambda: callback(channel))


def event_detected(channel):
    """Returns True if an edge has occurred on a given GPIO.
    You need to enable edge detection using add_event_detect() first.

    Args:
        channel (int): either board pin number or BCM number depending on which mode is set.
    """
    gpio = _gpio_list.get(channel)

    if gpio.direction != "in":
        raise RuntimeError("You must setup() the GPIO channel as an input "
                           "first")
    return gpio.event_detected()


def gpio_function(channel):
    """Return the current GPIO function (IN, OUT, PWM, SERIAL, I2C, SPI)

    Args:
        channel: either board pin number or BCM number depending on which mode is set.

    Returns:
        IN, OUT, PWM, SERIAL, I2C, SPI, UNKNOWN
    """
    funcstr = _gpio_list.gpio_function(channel)
    toval = { 'IN': IN, 'OUT': OUT, 'SPI': SPI, 'I2C': I2C,
             'PWM': HARD_PWM, 'SERIAL': SERIAL, 'UNKNOWN': UNKNOWN }
    return toval[funcstr]


def setwarnings(state):
    """Enable or disable warning messages

    Args:
        state (bool): True or False
    """
    _gpio_list.setwarnings(state)


class PWM(object):
    def __init__(self, channel, frequency_hz):
        gpio = _gpio_list.get(channel)

        if gpio.direction != "out":
            raise RuntimeError("You must setup() the GPIO channel as an output "
                               "first")

        gpio.pwm_init(frequency_hz)
        self.gpio = gpio


    def start(self, duty_cycle_percent):
        """Start software PWM

        Args:
            duty_cycle_percent: the duty cycle (0.0 to 100.0)
        """
        self.gpio.pwm.duty_cycle = duty_cycle_percent / 100.0
        self.gpio.pwm.enable()


    def ChangeFrequency(self, frequency_hz):
        """Change the frequency

        Args:
            frequency: frequency in Hz (freq > 1.0)
        """
        self.gpio.pwm.frequency = frequency_hz


    def ChangeDutyCycle(self, duty_cycle_percent):
        """Change the duty cycle

        Args:
            duty_cycle_percent: between 0.0 and 100.0
        """
        self.gpio.pwm.duty_cycle = duty_cycle_percent / 100.0


    def stop(self):
        """Stop software PWM
        """
        self.gpio.pwm.disable()


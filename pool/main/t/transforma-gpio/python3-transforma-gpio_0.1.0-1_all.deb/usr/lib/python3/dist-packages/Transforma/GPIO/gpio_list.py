# SPDX-FileCopyrightText: 2024 VIA Technologies, Inc.
#
# SPDX-License-Identifier: Apache-2.0

from periphery import GPIO, PWM
import threading
import time

# Transforma GPIO numbers
_gpios = [
     -1,       #  ~
     -1,  -1,  #  1,  2
     60,  -1,  #  3,  4
     59,  -1,  #  5,  6
     39,  35,  #  7,  8
     -1,  36,  #  9, 10
      0, 121,  # 11, 12
     37,  -1,  # 13, 14
     41,  75,  # 15, 16
     -1,  40,  # 17, 18
     82,  -1,  # 19, 20
     81,  38,  # 21, 22
     80,  79,  # 23, 24
     -1,  90,  # 25, 26
     56,  55,  # 27, 28
      1,  -1,  # 29, 30
    112,  28,  # 31, 32
     30,  -1,  # 33, 34
    122,  76,  # 35, 36
    111, 124,  # 37, 38
     -1, 123,  # 39, 40
]

# GPIO number to pwm channel
_pwm_channel = { 28: 3, 30: 1 }

# BCM GPIO number to pin number
_bcm_gpio_to_pin = {
    2: 3, 3: 5, 4: 7, 17: 11, 27: 13, 22: 15, 10: 19, 9: 21, 11: 23,
    0: 27, 5: 29, 6: 31, 13: 33, 19: 35, 26: 37,
    14: 8, 15: 10, 18: 12, 23: 16, 24: 18, 25: 22, 8: 24, 7: 26, 1: 28,
    12: 32, 16: 36, 20: 38, 21: 40,
}

_gpio_warnings = True

class _Gpio:
    def __init__(self, line):
        self.line = line
        self.gpio = None
        self.direction = "out"
        self.edge = "none"
        self.timestamp = 0
        self.callbacks = []
        self.detector = None
        self.events = []
        self.lock = threading.Lock()
        self.pwm = None

        # constants
        self.max_callbacks = 5
        self.max_events = 5


    def setup(self, direction, bias, initial=None):
        self.lock.acquire()
        self.path = "/dev/gpiochip0"
        self.direction = direction
        self.bias = bias
        self.gpio = GPIO(self.path, self.line, self.direction, edge=self.edge,
                         bias=self.bias)
        self.lock.release()


    def _reload(self):
        self.lock.acquire()
        self.gpio.close()
        self.lock.release()

        self.setup(self.direction, self.bias)

    
    def read(self):
        return self.gpio.read()


    def write(self, value):
        return self.gpio.write(value)


    def wait_for_edge(self, edge, bouncetime=None, timeout=None):
        if self.edge == "none":
            self.edge = edge
            self._reload()

        elif self.edge != "both" and self.edge != edge:
            raise RuntimeError("Conflicting edge detection event "
                               "already exists for this GPIO channel")

        if timeout is not None:
            timeout /= 1000  # ms to sec

        while True:
            if self.gpio.poll(timeout) is False:
                return False

            event, timestamp = self.gpio.read_event()

            duration_ms = (timestamp - self.timestamp) / 1000000  # ns to ms

            if bouncetime is not None and duration_ms < bouncetime:
                pass

            elif edge == "both" or edge == event:
                self.timestamp = timestamp
                return True


    def _eventloop(self, edge, bouncetime=None):
        while self.edge != "none":
            if self.wait_for_edge(edge, bouncetime, timeout=250) == True:
                self.lock.acquire()

                if len(self.events) >= self.max_events:
                    self.events.clear()

                self.events += [edge]

                for cb in self.callbacks:
                    cb()

                self.lock.release()


    def add_event_detect(self, edge, bouncetime=None):
        if self.detector is not None:
            self.remove_event_detect()

        self.edge = edge
        self._reload()

        self.detector = threading.Thread(target=self._eventloop, args=(edge, bouncetime))
        self.detector.start()

        # Wait the thread start
        time.sleep(0.5)


    def remove_event_detect(self, timeout=0.5):
        if self.detector is None:
            return

        self.edge = "none"

        # Wait the threads stop
        time.sleep(1)

        self.detector.join(timeout)
        self.detector = None

        self.lock.acquire()
        self.events.clear()
        self.lock.release()

        self._reload()


    def add_event_callback(self, callback):
        if len(self.callbacks) >= self.max_callbacks:
            raise RuntimeError("Too many callbacks")

        self.lock.acquire()
        self.callbacks += [callback]
        self.lock.release()


    def event_detected(self):
        if len(self.events) > 0:
            self.lock.acquire()
            self.events.clear()
            self.lock.release()
            return True

        return False


    def cleanup(self):
        if self.gpio is not None:
            self.remove_event_detect()

            self.lock.acquire()
            self.gpio.close()
            self.gpio = None
            self.lock.release()


    def pwm_init(self, frequency_hz):
        if self.line not in _pwm_channel.keys():
            raise ValueError("PWM channel not found!")

        if self.pwm is None:
            self.pwm = PWM(0, _pwm_channel[self.line])
            self.pwm.frequency = frequency_hz


class _GpioList:
    def __init__(self):
        self.list = list()
        self.mode = None


    def setmode(self, mode):
        if self.mode and mode != self.mode and len(self.list) > 0:
            raise ValueError("A different mode has already been set!")

        if mode in ['BOARD', 'BCM', 'TRANSFORMA']:
            self.mode = mode
        else:
            raise ValueError("An invalid mode was passed to setmode()!")


    def getmode(self):
        return self.mode


    def _getline(self, channel):
        if self.mode is None:
            return channel

        match self.mode:
            case 'BOARD':
                line = _gpios[channel]
            case 'BCM':
                line = _gpios[_bcm_gpio_to_pin[channel]]
            case 'TRANSFORMA':
                line = channel
            case _:
                raise ValueError("GPIO line is not available!")

        return line


    def get(self, channel):
        line = self._getline(channel)

        for gpio in self.list:
            if gpio.line == line:
                return gpio

        gpio = _Gpio(line)
        self.list.append(gpio)
        return gpio


    def cleanup(self, channel):
        if channel is None:
            for gpio in self.list:
                gpio.cleanup()
                self.list.remove(gpio)
        else:
            line = self._getline(channel)
            for gpio in self.list:
                if gpio.line == line:
                    gpio.cleanup()
                    self.list.remove(gpio)
                    break
       

    def gpio_function(self, channel):
        line = self._getline(channel)

        # IN, OUT, SPI, I2C, PWM, SERIAL, UNKNOWN

        for gpio in self.list:
            if gpio.line == line:
                return "IN" if gpio.direction == "in" else "OUT"
        
        if line in [_gpios[i] for i in [19, 21, 23, 24]]:
            return "SPI"
        elif line in [_gpios[i] for i in [3, 5, 27, 28]]:
            return "I2C"
        elif line in [_gpios[i] for i in [32, 33]]:
            return "PWM"
        elif line in [_gpios[i] for i in [8, 10]]:
            return "SERIAL"
        else:
            return "UNKNOWN"


    def setwarnings(self, state):
        global _gpio_warnings
        _gpio_warnings = bool(state)

